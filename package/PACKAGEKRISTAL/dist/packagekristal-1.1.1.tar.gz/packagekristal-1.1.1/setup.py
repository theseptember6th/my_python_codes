from setuptools import setup
setup(name="packagekristal",
      version="1.1.1",
      description="This is Kristal's custom python package",
      long_description="Assume this as a long description of the package",
      author="kristal",
      packages=['packagekristal'],
      install_requires=[]
      )


