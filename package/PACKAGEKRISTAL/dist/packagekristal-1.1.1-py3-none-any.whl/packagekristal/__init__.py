#assume this as heavy function
def veryheavyfunc(number):
    print("this is the function")
    return number