#assume this as heavy function
class kristal:
    def __init__(self):
        print("Constructor is made")
    
    def veryheavyfunc(self,number):
        print("this is the function")
        return number
    